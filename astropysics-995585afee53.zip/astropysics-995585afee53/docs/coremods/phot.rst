
.. automodule:: astropysics.phot
   :members:
   :undoc-members:
   :show-inheritance:
