
.. automodule:: astropysics.publication
   :members:
   :undoc-members:
   :show-inheritance:
