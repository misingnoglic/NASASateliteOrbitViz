
.. automodule:: astropysics.plotting
   :members:
   :undoc-members:
   :show-inheritance:
   
