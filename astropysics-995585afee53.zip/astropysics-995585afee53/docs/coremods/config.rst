
.. automodule:: astropysics.config
   :members:
   :undoc-members:
   :show-inheritance:
