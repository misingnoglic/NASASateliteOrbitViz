   
.. automodule:: astropysics.models
   :members:
   :undoc-members:
   :show-inheritance:
