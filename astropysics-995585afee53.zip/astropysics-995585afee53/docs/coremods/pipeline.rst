
.. automodule:: astropysics.pipeline
   :members:
   :undoc-members:
   :show-inheritance:
