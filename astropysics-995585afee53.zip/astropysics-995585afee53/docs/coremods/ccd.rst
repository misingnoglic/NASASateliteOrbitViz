
.. automodule:: astropysics.ccd
   :members:
   :undoc-members:
   :show-inheritance:
