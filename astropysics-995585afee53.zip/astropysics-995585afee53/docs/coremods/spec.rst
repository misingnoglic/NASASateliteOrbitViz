
.. automodule:: astropysics.spec
   :members:
   :undoc-members:
   :show-inheritance:
   
.. automethod:: astropysics.spec.HasSpecUnits._applyUnits
