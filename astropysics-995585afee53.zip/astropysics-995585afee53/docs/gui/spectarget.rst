
Spectarget -- MOS Targeting
===========================

This application is a tool based on `Traits <http://code.enthought.com/projects/traits/>`_ for interactively identifying spectroscopic targets for use with a multi-object spectograph. Note that this module is a bit rough around the edges and hasn't been too tested with anything other than `Keck/DEIMOS <http://www2.keck.hawaii.edu/inst/deimos/>`_.

.. automodule:: astropysics.gui.spectarget
   :members:
   :undoc-members:
